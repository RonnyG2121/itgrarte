// Esto es un comentario de una sola línea
let nombre = "Itgrarte";
// Esto es una constante
const pi = 3.14;


// Mostrando un mensaje
// console.log("Valor del nombre: " + nombre);

// Mostrando información en el html
document.getElementById("saludo").textContent = `Saludo desde la fundación: ${nombre}`;